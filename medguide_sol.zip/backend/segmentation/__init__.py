"""Segmentation services for Medix."""
